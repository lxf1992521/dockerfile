CPACK_STARTUP_SHORTCUTS
-----------------------

Species a list of shortcut names that should be created in the Startup folder
for this file.

The property is currently only supported by the WIX generator.

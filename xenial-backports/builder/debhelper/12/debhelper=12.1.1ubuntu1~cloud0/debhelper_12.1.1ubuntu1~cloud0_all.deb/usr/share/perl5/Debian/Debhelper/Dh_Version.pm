package Debian::Debhelper::Dh_Version;
$version='12.1.1ubuntu1~cloud0';
1